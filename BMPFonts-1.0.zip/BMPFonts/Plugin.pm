package Plugins::BMPFonts::Plugin;

use base qw(Slim::Plugin::Base);

1;
